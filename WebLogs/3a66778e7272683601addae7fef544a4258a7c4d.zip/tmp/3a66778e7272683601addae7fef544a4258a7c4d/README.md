# log
This directory is used to store log data about application exceptions and details about accesses. **It has to be writable!**